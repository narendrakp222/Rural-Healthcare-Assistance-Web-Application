# Rural Healthcare Assistance Web Application

A professional Flask + SQLite healthcare management portal created for a B.Tech Community Service Project demonstration.

## Features

- User registration, login, logout, hashed passwords, protected routes, and CSRF protection
- Patient dashboard with profile completion, medicines, appointments, records, emergency contacts, and health tips
- CRUD-style modules for profile, medical records, medicine reminders, appointments, and emergency contacts
- Secure uploads for prescription PDFs and profile/article images
- Health awareness articles, nearby hospital directory with Google Maps links, and feedback
- Admin panel for users, records, appointments, articles, hospitals, statistics, and feedback
- Bootstrap 5 responsive UI, Font Awesome icons, dark mode, flash messages, search, and filtering

## Project Structure

```text
healthcare_app/
  app.py
  config.py
  extensions.py
  forms.py
  models.py
  requirements.txt
  instance/database.db
  routes/
  templates/
  static/
```

## Installation

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Demo Accounts

- Admin: `admin@healthcare.local` / `admin123`
- Patient: `patient@example.com` / `patient123`

The SQLite database and sample data are created automatically on the first run.

## Database Tables

- `User`
- `Profile`
- `MedicalRecord`
- `Medicine`
- `Appointment`
- `EmergencyContact`
- `HealthArticle`
- `Hospital`
- `Feedback`

## Screenshots Section

Add screenshots of:

- Home page
- Patient dashboard
- Medical records page
- Medicine reminders page
- Nearby hospitals page
- Admin dashboard

## Future Scope

- AI symptom checker
- Telemedicine consultation
- SMS and email reminders
- Cloud storage for prescriptions
- Multilingual support for rural communities
- Machine learning health prediction
- Wearable device integration

## Production Notes

Before deployment, change `SECRET_KEY`, disable debug mode, use environment variables, serve uploaded files carefully, and consider a production database such as PostgreSQL.

